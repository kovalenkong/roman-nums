
class RTextError(Exception):
    pass


class RomanNumsError(Exception):
    pass


class RomanValidationError(Exception):
    pass
